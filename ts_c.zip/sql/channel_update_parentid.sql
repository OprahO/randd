update channels
 set channel_parent_id = :parent_id:
 where channel_id = :channel_id: ;
